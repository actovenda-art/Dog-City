import React from "react";

export default function Resumos() {
  return (
    <div className="p-6">
      <h1 className="text-2xl font-bold text-gray-900">Resumos</h1>
    </div>
  );
}