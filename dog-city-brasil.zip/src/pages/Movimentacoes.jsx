import React from "react";

export default function Movimentacoes() {
  return (
    <div className="p-6">
      <h1 className="text-2xl font-bold text-gray-900">Movimentações Futuras</h1>
    </div>
  );
}