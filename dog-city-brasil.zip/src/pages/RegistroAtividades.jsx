import React from "react";

export default function RegistroAtividades() {
  return (
    <div className="p-6">
      <h1 className="text-2xl font-bold text-gray-900">Registro de Atividades</h1>
    </div>
  );
}